#include <iostream>
void log(const char* s) {
    std::clog << s << "\n";
}

int add(int x, int y) {
    log("called add.");
    return x+y;
}