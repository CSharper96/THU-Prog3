#include <iostream>
void log(const char* s) {
    std::clog << s << "\n";
}

int mul(int x, int y) {
    log("called mul.");
    return x+y;
}