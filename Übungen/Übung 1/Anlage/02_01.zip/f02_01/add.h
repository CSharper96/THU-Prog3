#ifndef __ADD_H
#define __ADD_H

int add(int x, int y);

#endif