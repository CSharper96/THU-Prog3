#include "add.h"
#include "mul.h"

int main(int, char**) {
    return add( mul(8,2), 4 );
}
