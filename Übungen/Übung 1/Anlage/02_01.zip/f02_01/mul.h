#ifndef __MUL_H
#define __MUL_H

int mul(int x, int y);

#endif